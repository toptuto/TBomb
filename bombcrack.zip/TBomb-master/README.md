# TBomb
This is a SMS Bomber for Debian Based Linux And Termux..

This Script is Only For Educational Purposes or To Prank.
 Do not Use This To Harm Others.
 I Am Not Responsible For The Misuse Of The Script.

The Script Requires A working Net Connection To Work..
No Balance will be deducted for using this script to send SMS...

While Using The Infinite Bomb Use 2-3 Seconds Delay And 10 to 20 Threads For Maximum Performance...
<br>Don't Put Spaces In Between Number Ex- 9999999999

 Make Sure To Update it for New Versions...

 That's All !!!

Make Sure You Are Using python3

## Usage
Run These Commands To Run TBomb<br>
### For Termux
To USE the Script Type The Following Commands in Termux...

```
apt install git
git clone https://github.com/TheSpeedX/TBomb.git
cd TBomb
chmod +x TBomb.sh
./TBomb.sh
```

### For Linux (Debian Based)

To USE the Script Type The Following Commands in Linux Terminal...

```
sudo apt install git
git clone https://github.com/TheSpeedX/TBomb.git
cd TBomb
chmod +x TBomb.sh
sudo bash TBomb.sh
```

Now the Script Will Execute..

## FEATURES 

 [+] Lots Of APIs <br>
 [+] Unlimited And Super-Fast Bombing <br>
 [+] International Bombing Available <br>
 [+] Call Bombing <br>
 [+] Protection List <br>
 [+] Updated Frequently <br>
 [+] Automated Future Updates <br>
 [+] Easy To Use And Embed in Code <br>
 
## DEMO
<br>
Watch Indian Bombing Method <a href="https://youtu.be/9KWkwsr_QGw">here</a> <br><br>
Watch International Bombing Method <a href="https://youtu.be/JqsHkyIcnPM">here</a> <br><br>

# CONTRIBUTORS
<br><br>
[*]  SpeedX<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[-] Mail At: ggspeedx29@gmail.com  <br>
[*]  The Black Hacker Roxstar<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[-] Ping At: http://wa.me/917600140353 <br>
[*]  Rieltar<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[-] Ping At: https://t.me/Rieltar  <br>
[*]  0n1cOn3 (Stefan)<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[-] Mail At: 0n1cOn3@gmx.ch <br>

## Donators
<br><br>
[@] 34D30Y ( 34db0y@protonmail.com  )
<br>
[@] SC AMAN
<br><br>
# CONTACT
For Any Queries Join Us On WhatsApp!!!
          Group Link: http://bit.do/speedxgit
  <a href="http://bit.do/speedxgit">Join My Group</a>

           Mail: ggspeedx29@gmail.com

           YouTube Channel: https://www.youtube.com/c/GyanaTech
  <a href="https://www.youtube.com/c/GyanaTech">Check My Channel</a>
